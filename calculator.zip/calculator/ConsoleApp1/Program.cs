﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        [DllImport("D:\\kurs\\MathLibrary\\x64\\Debug\\MathLIbrary.dll")]
        static extern double add(double a, double b);

        static void Main(string[] args)
        {
            
            add(1, 2);
        }
    }
}
