﻿using System;
using System.Runtime.InteropServices;

namespace MathLibraryInterop
{
    public static class MathLibrary
    {
        [DllImport("MathLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double Add(double a, double b);

        [DllImport("MathLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double Subtract(double a, double b);

        [DllImport("MathLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double Multiply(double a, double b);

        [DllImport("MathLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double Divide(double a, double b);

        [DllImport("MathLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double Power(double a, double b);

        [DllImport("MathLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double Sqrt(double a);

        [DllImport("MathLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double Factorial(int a);
    }
}
