﻿using System;
using System.Runtime.InteropServices;

namespace calculator
{
   
    public class Calc : InterfaceCalc
    {

        [DllImport("MathLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int Factorial(int n);

        [DllImport("MathLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double Power(double baseValue, double exponent);

        [DllImport("MathLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double SquareRoot(double x);

        [DllImport("MathLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double Sine(double angle);

        [DllImport("MathLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double Add(double a, double b);

        [DllImport("MathLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double Subtract(double a, double b);

        [DllImport("MathLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double Multiply(double a, double b);

        [DllImport("MathLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern double Divide(double a, double b);

        private double a = 0;
        private double memory = 0;

        public void Put_A(double a)
        {
            this.a = a;
        }

        public void Clear_A()
        {
            a = 0;
        }

        public double Multiplication(double b)
        {
            return Multiply(a, b);
        }

        public double Division(double b)
        {
            return Divide(a, b);
        }

        public double Sum(double b)
        {
            return Add(a, b);
        }

        public double Subtraction(double b) // вычитание
        {
            return Subtract(a, b);
        }

        public double SqrtX(double b)
        {
            return Power(a, 1 / b);
        }

        public double DegreeY(double b)
        {
            return Power(a, b);
        }

        public double Sqrt()
        {
            return SquareRoot(a);
        }

        public double Square()
        {
            return Power(a, 2.0);
        }

        public double Factorial()
        {
            return Factorial((int)a);
        }

        // показать содержимое регистра памяти
        public double MemoryShow()
        {
            return memory;
        }

        // стереть содержимое регистра памяти
        public void Memory_Clear()
        {
            memory = 0.0;
        }

        // * / + - к регистру памяти
        public void M_Multiplication(double b)
        {
            memory *= b;
        }

        public void M_Division(double b)
        {
            memory /= b;
        }

        public void M_Sum(double b)
        {
            memory += b;
        }

        public void M_Subtraction(double b)
        {
            memory -= b;
        }
    }
}
