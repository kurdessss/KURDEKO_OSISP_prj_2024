﻿namespace calculator
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.buttonPoint = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonMult = new System.Windows.Forms.Button();
            this.buttonDiv = new System.Windows.Forms.Button();
            this.buttonPlus = new System.Windows.Forms.Button();
            this.buttonMinus = new System.Windows.Forms.Button();
            this.buttonCalc = new System.Windows.Forms.Button();
            this.buttonSqrt = new System.Windows.Forms.Button();
            this.buttonSquare = new System.Windows.Forms.Button();
            this.buttonDegreeY = new System.Windows.Forms.Button();
            this.buttonFactorial = new System.Windows.Forms.Button();
            this.buttonSqrtX = new System.Windows.Forms.Button();
            this.buttonMPlus = new System.Windows.Forms.Button();
            this.buttonMMinus = new System.Windows.Forms.Button();
            this.buttonMMult = new System.Windows.Forms.Button();
            this.buttonMDiv = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.labelNumber = new System.Windows.Forms.Label();
            this.buttonChangeSign = new System.Windows.Forms.Button();
            this.buttonMRC = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.button7.Location = new System.Drawing.Point(118, 154);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(45, 38);
            this.button7.TabIndex = 0;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.button8.Location = new System.Drawing.Point(178, 154);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(45, 38);
            this.button8.TabIndex = 1;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.button9.Location = new System.Drawing.Point(238, 154);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(45, 38);
            this.button9.TabIndex = 2;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.button5.Location = new System.Drawing.Point(178, 214);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(45, 38);
            this.button5.TabIndex = 3;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.button6.Location = new System.Drawing.Point(238, 214);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(45, 38);
            this.button6.TabIndex = 4;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button0
            // 
            this.button0.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.button0.Location = new System.Drawing.Point(118, 331);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(45, 38);
            this.button0.TabIndex = 5;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = true;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.button3.Location = new System.Drawing.Point(238, 274);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(45, 38);
            this.button3.TabIndex = 6;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.button2.Location = new System.Drawing.Point(178, 272);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(45, 38);
            this.button2.TabIndex = 7;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.button1.Location = new System.Drawing.Point(118, 272);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(45, 38);
            this.button1.TabIndex = 8;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.button4.Location = new System.Drawing.Point(118, 213);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(45, 38);
            this.button4.TabIndex = 9;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // buttonPoint
            // 
            this.buttonPoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonPoint.Location = new System.Drawing.Point(178, 331);
            this.buttonPoint.Name = "buttonPoint";
            this.buttonPoint.Size = new System.Drawing.Size(45, 38);
            this.buttonPoint.TabIndex = 10;
            this.buttonPoint.Text = ",";
            this.buttonPoint.UseVisualStyleBackColor = true;
            this.buttonPoint.Click += new System.EventHandler(this.buttonPoint_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonClear.Location = new System.Drawing.Point(238, 331);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(45, 38);
            this.buttonClear.TabIndex = 11;
            this.buttonClear.Text = "CE";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonMult
            // 
            this.buttonMult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonMult.Location = new System.Drawing.Point(309, 154);
            this.buttonMult.Name = "buttonMult";
            this.buttonMult.Size = new System.Drawing.Size(45, 38);
            this.buttonMult.TabIndex = 12;
            this.buttonMult.Text = "×";
            this.buttonMult.UseVisualStyleBackColor = true;
            this.buttonMult.Click += new System.EventHandler(this.buttonMult_Click);
            // 
            // buttonDiv
            // 
            this.buttonDiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonDiv.Location = new System.Drawing.Point(309, 214);
            this.buttonDiv.Name = "buttonDiv";
            this.buttonDiv.Size = new System.Drawing.Size(45, 38);
            this.buttonDiv.TabIndex = 13;
            this.buttonDiv.Text = "÷";
            this.buttonDiv.UseVisualStyleBackColor = true;
            this.buttonDiv.Click += new System.EventHandler(this.buttonDiv_Click);
            // 
            // buttonPlus
            // 
            this.buttonPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonPlus.Location = new System.Drawing.Point(309, 274);
            this.buttonPlus.Name = "buttonPlus";
            this.buttonPlus.Size = new System.Drawing.Size(45, 38);
            this.buttonPlus.TabIndex = 14;
            this.buttonPlus.Text = "+";
            this.buttonPlus.UseVisualStyleBackColor = true;
            this.buttonPlus.Click += new System.EventHandler(this.buttonPlus_Click);
            // 
            // buttonMinus
            // 
            this.buttonMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonMinus.Location = new System.Drawing.Point(309, 331);
            this.buttonMinus.Name = "buttonMinus";
            this.buttonMinus.Size = new System.Drawing.Size(45, 38);
            this.buttonMinus.TabIndex = 15;
            this.buttonMinus.Text = "-";
            this.buttonMinus.UseVisualStyleBackColor = true;
            this.buttonMinus.Click += new System.EventHandler(this.buttonMinus_Click);
            // 
            // buttonCalc
            // 
            this.buttonCalc.BackColor = System.Drawing.SystemColors.Highlight;
            this.buttonCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonCalc.Location = new System.Drawing.Point(238, 387);
            this.buttonCalc.Name = "buttonCalc";
            this.buttonCalc.Size = new System.Drawing.Size(116, 38);
            this.buttonCalc.TabIndex = 16;
            this.buttonCalc.Text = "=";
            this.buttonCalc.UseVisualStyleBackColor = false;
            this.buttonCalc.Click += new System.EventHandler(this.buttonCalc_Click);
            // 
            // buttonSqrt
            // 
            this.buttonSqrt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonSqrt.Location = new System.Drawing.Point(421, 154);
            this.buttonSqrt.Name = "buttonSqrt";
            this.buttonSqrt.Size = new System.Drawing.Size(45, 38);
            this.buttonSqrt.TabIndex = 17;
            this.buttonSqrt.Text = "√";
            this.buttonSqrt.UseVisualStyleBackColor = true;
            this.buttonSqrt.Click += new System.EventHandler(this.buttonSqrt_Click);
            // 
            // buttonSquare
            // 
            this.buttonSquare.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.buttonSquare.Location = new System.Drawing.Point(421, 213);
            this.buttonSquare.Name = "buttonSquare";
            this.buttonSquare.Size = new System.Drawing.Size(45, 38);
            this.buttonSquare.TabIndex = 18;
            this.buttonSquare.Text = "x^2";
            this.buttonSquare.UseVisualStyleBackColor = true;
            this.buttonSquare.Click += new System.EventHandler(this.buttonSquare_Click);
            // 
            // buttonDegreeY
            // 
            this.buttonDegreeY.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.buttonDegreeY.Location = new System.Drawing.Point(421, 331);
            this.buttonDegreeY.Name = "buttonDegreeY";
            this.buttonDegreeY.Size = new System.Drawing.Size(45, 38);
            this.buttonDegreeY.TabIndex = 19;
            this.buttonDegreeY.Text = "x^y";
            this.buttonDegreeY.UseVisualStyleBackColor = true;
            this.buttonDegreeY.Click += new System.EventHandler(this.buttonDegreeY_Click);
            // 
            // buttonFactorial
            // 
            this.buttonFactorial.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonFactorial.Location = new System.Drawing.Point(421, 387);
            this.buttonFactorial.Name = "buttonFactorial";
            this.buttonFactorial.Size = new System.Drawing.Size(45, 38);
            this.buttonFactorial.TabIndex = 20;
            this.buttonFactorial.Text = "n!";
            this.buttonFactorial.UseVisualStyleBackColor = true;
            this.buttonFactorial.Click += new System.EventHandler(this.buttonFactorial_Click);
            // 
            // buttonSqrtX
            // 
            this.buttonSqrtX.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonSqrtX.Location = new System.Drawing.Point(421, 274);
            this.buttonSqrtX.Name = "buttonSqrtX";
            this.buttonSqrtX.Size = new System.Drawing.Size(45, 38);
            this.buttonSqrtX.TabIndex = 21;
            this.buttonSqrtX.Text = "x√";
            this.buttonSqrtX.UseVisualStyleBackColor = true;
            this.buttonSqrtX.Click += new System.EventHandler(this.buttonSqrtX_Click);
            // 
            // buttonMPlus
            // 
            this.buttonMPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonMPlus.Location = new System.Drawing.Point(118, 89);
            this.buttonMPlus.Name = "buttonMPlus";
            this.buttonMPlus.Size = new System.Drawing.Size(45, 38);
            this.buttonMPlus.TabIndex = 23;
            this.buttonMPlus.Text = "М+";
            this.buttonMPlus.UseVisualStyleBackColor = true;
            this.buttonMPlus.Click += new System.EventHandler(this.buttonMPlus_Click);
            // 
            // buttonMMinus
            // 
            this.buttonMMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonMMinus.Location = new System.Drawing.Point(178, 89);
            this.buttonMMinus.Name = "buttonMMinus";
            this.buttonMMinus.Size = new System.Drawing.Size(45, 38);
            this.buttonMMinus.TabIndex = 24;
            this.buttonMMinus.Text = "М-";
            this.buttonMMinus.UseVisualStyleBackColor = true;
            this.buttonMMinus.Click += new System.EventHandler(this.buttonMMinus_Click);
            // 
            // buttonMMult
            // 
            this.buttonMMult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonMMult.Location = new System.Drawing.Point(238, 89);
            this.buttonMMult.Name = "buttonMMult";
            this.buttonMMult.Size = new System.Drawing.Size(45, 38);
            this.buttonMMult.TabIndex = 25;
            this.buttonMMult.Text = "М×";
            this.buttonMMult.UseVisualStyleBackColor = true;
            this.buttonMMult.Click += new System.EventHandler(this.buttonMMult_Click);
            // 
            // buttonMDiv
            // 
            this.buttonMDiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonMDiv.Location = new System.Drawing.Point(309, 89);
            this.buttonMDiv.Name = "buttonMDiv";
            this.buttonMDiv.Size = new System.Drawing.Size(45, 38);
            this.buttonMDiv.TabIndex = 26;
            this.buttonMDiv.Text = "М÷";
            this.buttonMDiv.UseVisualStyleBackColor = true;
            this.buttonMDiv.Click += new System.EventHandler(this.buttonMDiv_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.labelNumber);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.groupBox1.Size = new System.Drawing.Size(471, 61);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            // 
            // labelNumber
            // 
            this.labelNumber.AutoSize = true;
            this.labelNumber.Dock = System.Windows.Forms.DockStyle.Right;
            this.labelNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 27F);
            this.labelNumber.Location = new System.Drawing.Point(221, 16);
            this.labelNumber.Name = "labelNumber";
            this.labelNumber.Size = new System.Drawing.Size(247, 40);
            this.labelNumber.TabIndex = 0;
            this.labelNumber.Text = "0123456789.0";
            // 
            // buttonChangeSign
            // 
            this.buttonChangeSign.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonChangeSign.Location = new System.Drawing.Point(421, 89);
            this.buttonChangeSign.Name = "buttonChangeSign";
            this.buttonChangeSign.Size = new System.Drawing.Size(45, 38);
            this.buttonChangeSign.TabIndex = 28;
            this.buttonChangeSign.Text = "+/-";
            this.buttonChangeSign.UseVisualStyleBackColor = true;
            this.buttonChangeSign.Click += new System.EventHandler(this.buttonChangeSign_Click);
            // 
            // buttonMRC
            // 
            this.buttonMRC.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.buttonMRC.Location = new System.Drawing.Point(32, 89);
            this.buttonMRC.Name = "buttonMRC";
            this.buttonMRC.Size = new System.Drawing.Size(70, 38);
            this.buttonMRC.TabIndex = 29;
            this.buttonMRC.Text = "МRC";
            this.buttonMRC.UseVisualStyleBackColor = true;
            this.buttonMRC.Click += new System.EventHandler(this.buttonMRC_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 439);
            this.Controls.Add(this.buttonMRC);
            this.Controls.Add(this.buttonChangeSign);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonMDiv);
            this.Controls.Add(this.buttonMMult);
            this.Controls.Add(this.buttonMMinus);
            this.Controls.Add(this.buttonMPlus);
            this.Controls.Add(this.buttonSqrtX);
            this.Controls.Add(this.buttonFactorial);
            this.Controls.Add(this.buttonDegreeY);
            this.Controls.Add(this.buttonSquare);
            this.Controls.Add(this.buttonSqrt);
            this.Controls.Add(this.buttonCalc);
            this.Controls.Add(this.buttonMinus);
            this.Controls.Add(this.buttonPlus);
            this.Controls.Add(this.buttonDiv);
            this.Controls.Add(this.buttonMult);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonPoint);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Name = "Form1";
            this.Text = "Калькулятор - vscode.ru";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button buttonPoint;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonMult;
        private System.Windows.Forms.Button buttonDiv;
        private System.Windows.Forms.Button buttonPlus;
        private System.Windows.Forms.Button buttonMinus;
        private System.Windows.Forms.Button buttonCalc;
        private System.Windows.Forms.Button buttonSqrt;
        private System.Windows.Forms.Button buttonSquare;
        private System.Windows.Forms.Button buttonDegreeY;
        private System.Windows.Forms.Button buttonFactorial;
        private System.Windows.Forms.Button buttonSqrtX;
        private System.Windows.Forms.Button buttonMPlus;
        private System.Windows.Forms.Button buttonMMinus;
        private System.Windows.Forms.Button buttonMMult;
        private System.Windows.Forms.Button buttonMDiv;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label labelNumber;
        private System.Windows.Forms.Button buttonChangeSign;
        private System.Windows.Forms.Button buttonMRC;
    }
}

