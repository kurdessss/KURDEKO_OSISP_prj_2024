﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using UnitTestProject2;

namespace UnitTestProject2
{
	[TestClass]
	public class CalcTest
	{
		[TestMethod]
		public void Debit_WithValidAmount_UpdatesBalance()
		{
			double beginningBalance = 11.99;
			double debitAmount = -100.00;
			CalcTest account = new CalcTest();

			// Act and assert
			Assert.ThrowsException<System.ArgumentOutOfRangeException>(() => account.Equals(debitAmount));
			// return 		}
		}



	}
}
