﻿extern "C" {
    __declspec(dllexport) int factorial(int n);
    __declspec(dllexport) double power(double base, int exponent);
    __declspec(dllexport) double squareRoot(double x);
    __declspec(dllexport) double sine(double angle);
    __declspec(dllexport) double add(double a, double b);
    __declspec(dllexport) double subtract(double a, double b);
    __declspec(dllexport) double multiply(double a, double b);
    __declspec(dllexport) double divide(double a, double b);
}
