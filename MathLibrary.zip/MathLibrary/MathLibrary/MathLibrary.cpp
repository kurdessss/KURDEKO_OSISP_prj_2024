#include "pch.h"
#include <cmath>
#include "MathLibrary.h"

extern "C" {
    __declspec(dllexport) int Factorial(int n) {
        if (n <= 1)
            return 1;
        else
            return n * Factorial(n - 1);
    }

    __declspec(dllexport) double Power(double base, double exponent) {
        return std::pow(base, exponent);
    }

    __declspec(dllexport) double SquareRoot(double x) {
        return std::sqrt(x);
    }

    __declspec(dllexport) double Sine(double angle) {
        return std::sin(angle);
    }

    __declspec(dllexport) double Add(double a, double b) {
        return a + b;
    }

    __declspec(dllexport) double Subtract(double a, double b) {
        return a - b;
    }

    __declspec(dllexport) double Multiply(double a, double b) {
        return a * b;
    }

    __declspec(dllexport) double Divide(double a, double b) {
        if (b == 0) {
            // Обработка деления на ноль
            return 0;
        }
        return a / b;
    }
}
